package com.sheryians.major;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;




@EnableAutoConfiguration(exclude= {SecurityAutoConfiguration.class})

@EnableJpaRepositories
@ComponentScan({"controllers","repositories",})
@SpringBootApplication(scanBasePackages = {"com.sheryians.major.controller"})


public class MajorApplication {
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(MajorApplication.class);

	}


	public static void main(String[] args) {
		SpringApplication.run(MajorApplication.class,args);
	}

}
