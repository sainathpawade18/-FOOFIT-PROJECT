package com.sheryians.major.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sheryians.major.model.Nutritionist_guide;
import com.sheryians.major.model.Product;
import com.sheryians.major.repository.Nutritionist_guideRepository;

@Service
public class Nutritionist_guideService  {
	
	
@Autowired
Nutritionist_guideRepository  nutritionist_guideRepository;
public List< Nutritionist_guide> getAllNutritionist_guide() {return  nutritionist_guideRepository.findAll();}
	
public void addNutritionist_guide(Nutritionist_guide nutritionist_guide) {
	nutritionist_guideRepository.save(nutritionist_guide);
} 
public void removeNutritionist_guideById(long id) {
	nutritionist_guideRepository.deleteById(id);
}
public Optional<Nutritionist_guide> getNutritionist_guideById(long id){
	 return nutritionist_guideRepository.findById(id);
}
public List<Nutritionist_guide> getAllNutritionist_guideByCategoryId(int id){
	 return nutritionist_guideRepository.findAllByCategory_Id(id); 
}
}
