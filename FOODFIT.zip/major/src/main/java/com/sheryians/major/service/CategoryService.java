package com.sheryians.major.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sheryians.major.model.Categeory;
import com.sheryians.major.repository.CategoryRepository;
import java.util.Optional;

@Service
public class CategoryService {
 @Autowired
 CategoryRepository categoryRepository;
 public List<Categeory> getAllCategory(){
	 return categoryRepository.findAll();
 }
 
 public void addCategory(Categeory category) {
	 categoryRepository.save(category);
 }
 public void removeCategoryById(int id) {
	 categoryRepository.deleteById(id);
 }
 public Optional<Categeory> getCategoryById(int id) {
	 return categoryRepository.findById(id);
 }
}
