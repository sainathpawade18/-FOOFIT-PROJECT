package com.sheryians.major.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sheryians.major.model.Categeory;

public interface CategoryRepository extends JpaRepository<Categeory,Integer> {
	

}
