package com.sheryians.major.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sheryians.major.dto.Nutritionist_guideDTO;
import com.sheryians.major.dto.ProductDTO;
import com.sheryians.major.model.Categeory;
import com.sheryians.major.model.Nutritionist_guide;
import com.sheryians.major.model.Product;

import com.sheryians.major.service.CategoryService;
import com.sheryians.major.service.Nutritionist_guideService;
import com.sheryians.major.service.ProductService;

@RestController
public class AdminController {
	public static String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/productImages";
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductService productService;
	@Autowired
	Nutritionist_guideService nutritionist_guideService;

	@GetMapping("/admin")
	public String adminHome() {
		return "adminHome";
	}

	@GetMapping("/admin/categories")
	public String getcat(Model model) {
		model.addAttribute("categories", categoryService.getAllCategory());
		return "categories";

	}

	@GetMapping("/admin/categories/add")
	public String getCatAdd(Model model) {
		model.addAttribute("category", new Categeory());
		return "categoriesAdd";

	}

	@PostMapping("/admin/categories/add")
	public String PostCatAdd(@ModelAttribute("category") Categeory category) {
		categoryService.addCategory(category);
		return "redirect:/admin/categories";

	}

	@GetMapping("/admin/categories/delete/{id}")
	public String deleteCat(@PathVariable int id) {
		categoryService.removeCategoryById(id);
		return "redirect:/admin/categories";
	}

	@GetMapping("/admin/categories/update/{id}")
	public String updateCat(@PathVariable int id, Model model) {
		Optional<Categeory> category = categoryService.getCategoryById(id);
		if (category.isPresent()) {
			model.addAttribute("category", category.get());
			return "categoriesAdd";
		} else
			return "404";
	}

//Product Section

	@GetMapping("/admin/products")
	public String products(Model model) {
		model.addAttribute("products", productService.getAllProduct());
		return "products";
	}

	@GetMapping("/admin/products/add")
	public String productAddGet(Model model) {
		model.addAttribute("productDTO", new ProductDTO());
		model.addAttribute("categories", categoryService.getAllCategory());
		return "productsAdd ";
	}

	@PostMapping("/admin/products/add")
	public String productAddPost(@ModelAttribute("productDTO") ProductDTO productDTO,
			@RequestParam("productImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		Product product = new Product();
		product.setId(productDTO.getId());
		product.setName(productDTO.getName());
		product.setCategory(categoryService.getCategoryById(productDTO.getCategoryId()).get());
		product.setPrice(productDTO.getPrice());
		product.setQuantity(productDTO.getQuantity());
		product.setDescription(productDTO.getDescription());
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();
			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		product.setImageName(imageUUID);
		productService.addProduct(product);
		return "redirect:/admin/products";
	}

	@GetMapping("/admin/product/delete/{id}")
	public String deleteProduct(@PathVariable long id) {
		productService.removeProductById(id);
		return "redirect:/admin/products";
	}

	@GetMapping("/admin/product/update/{id}")
	public String updateProductGet(@PathVariable long id, Model model) {
		Product product = productService.getProductById(id).get();
		ProductDTO productDTO = new ProductDTO();
		productDTO.setId(product.getId());
		productDTO.setName(product.getName());
		productDTO.setCategoryId(product.getCategory().getId());
		productDTO.setPrice(product.getPrice());
		productDTO.setQuantity(product.getQuantity());
		productDTO.setDescription(product.getDescription());
		productDTO.setImageName(product.getImageName());

		model.addAttribute("categories", categoryService.getAllCategory());
		model.addAttribute("productDTO", productDTO);

		return "productsAdd";

	}
	
	  // Nutrition section
	  
	  @GetMapping("/admin/nutritionist_guides") public String
	  nutritionist_guides(Model model) {
	  model.addAttribute("nutritionist_guides",nutritionist_guideService.
	  getAllNutritionist_guide()); return "nutritionist_guides" + ""; }
	  
	  @GetMapping("/admin/nutritionist_guides/add") public String
	  nutritionist_guidesAddGet(Model model) {
	  model.addAttribute("nutritionist_guideDTO",new Nutritionist_guideDTO());
	  model.addAttribute("nutritionist_guideDTO",categoryService.getAllCategory());
	  
	  return "nutritionist_guidesAdd";
	  
	  }
	  
	  @PostMapping("/admin/nutritionist_guides/add") public String
	  nutritionist_guideAddPost(@ModelAttribute("nutritionist_guideDTO")
	  Nutritionist_guideDTO nutritionist_guideDTO) throws IOException{
	  Nutritionist_guide nutritionist_guide = new Nutritionist_guide();
	  nutritionist_guide.setId(nutritionist_guideDTO.getId());
	  nutritionist_guide.setName(nutritionist_guideDTO.getName());
	  nutritionist_guide.setCategory(categoryService.getCategoryById(
	  nutritionist_guideDTO.getCategoryId()).get());
	  nutritionist_guide.setPrice(nutritionist_guideDTO.getPrice());
	  nutritionist_guide.setEmail(nutritionist_guideDTO.getEmail());
	  nutritionist_guide.setDescription(nutritionist_guideDTO.getDescription());
	  nutritionist_guide.setMobileno(nutritionist_guideDTO.getMobileno());
	  
	  nutritionist_guideService.addNutritionist_guide(nutritionist_guide); return
	  "redirect:/admin/nutritionist_guides"; }
	  
	  @GetMapping("/admin/nutritionist_guide/delete/{id}") public String
	  deleteNutritionist_guide(@PathVariable long id ) {
	  nutritionist_guideService.removeNutritionist_guideById(id); return
	  "redirect:/admin/nutritionist_guides"; }
	  
	  @GetMapping("/admin/nutritionist_guide/update/{id}") public String
	  updateNutritionist_guideGet(@PathVariable long id,Model model) {
	  Nutritionist_guide nutritionist_guide =
	  nutritionist_guideService.getNutritionist_guideById(id).get();
	  Nutritionist_guideDTO nutritionist_guideDTO = new Nutritionist_guideDTO();
	  nutritionist_guideDTO.setId(nutritionist_guide.getId());
	  nutritionist_guideDTO.setName(nutritionist_guide.getName());
	  nutritionist_guideDTO.setCategoryId(nutritionist_guide.getCategory().getId());
	  nutritionist_guideDTO.setPrice(nutritionist_guide.getPrice());
	  nutritionist_guideDTO.setEmail(nutritionist_guide.getEmail());
	  nutritionist_guideDTO.setMobileno(nutritionist_guide.getMobileno());
	  nutritionist_guideDTO.setDescription(nutritionist_guide.getDescription());
	  
	  
	  model.addAttribute("categories",categoryService.getAllCategory());
	  model.addAttribute("nutritionist_guidetDTO",nutritionist_guideDTO);
	  
	  
	  
	  return "nutritionist_guidesAdd";
	  
	  }
	  
	 
}
